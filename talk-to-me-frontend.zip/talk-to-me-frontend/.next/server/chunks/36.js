"use strict";
exports.id = 36;
exports.ids = [36];
exports.modules = {

/***/ 2202:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PR": () => (/* binding */ getUser),
/* harmony export */   "av": () => (/* binding */ setUser)
/* harmony export */ });
/* unused harmony export removeUser */
function getUser() {
    if (false) {}
    return {};
}
function setUser(user) {
    if (false) {}
}
function removeUser() {
    if (false) {}
}


/***/ }),

/***/ 2036:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ layout_AppLayout)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./src/features/auth/services/user.service.js
var user_service = __webpack_require__(2202);
;// CONCATENATED MODULE: ./src/assets/img/GTLogo.png
/* harmony default export */ const GTLogo = ({"src":"/_next/static/media/GTLogo.421a4a65.png","height":170,"width":442,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAADCAYAAACuyE5IAAAARElEQVR42mPAA2QZEhnyGP79++cAxP5AbAzEbkDs8///f4fP3744nL91sRCkYA4QrwTiPiBeAJRcAqRXA+mb////vwAAG883rEjQlHEAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":3});
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./src/features/layout/AppLayout.tsx






function AppLayout({ children  }) {
    const user = (0,user_service/* getUser */.PR)();
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "navbar",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "logo",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: GTLogo,
                            height: "40px",
                            width: "100px",
                            alt: "GreenTravels"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "greentravels",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                            children: "GreenTravels"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "knoppen",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "/",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                    className: "fa-solid fa-house",
                                    style: {
                                        fontSize: "20px",
                                        cursor: "pointer"
                                    }
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: user ? "/my-account" : "/login",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                    className: "fa-solid fa-user",
                                    style: {
                                        fontSize: "20px",
                                        cursor: "pointer"
                                    }
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "/shop",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                    className: "fa-solid fa-basket-shopping",
                                    style: {
                                        fontSize: "20px",
                                        cursor: "pointer"
                                    }
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                style: {
                    maxWidth: "100%"
                },
                children: children
            })
        ]
    });
}
/* harmony default export */ const layout_AppLayout = (AppLayout);


/***/ })

};
;