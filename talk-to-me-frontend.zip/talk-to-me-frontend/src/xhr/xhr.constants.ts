// Overwrite this for production
export const API_URL =  "https://api.greentravels.nl/api" // "http://localhost:8000/api";
export const API_SERVER = "localhost:8000";